package com.cg.movie.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
@Entity
public class Song {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int songCode; 
private String songName;
private int lengthInSeconds;
private String singer;
@ManyToOne
@JsonBackReference
private Movie movie;
public Song() {}
public Song(String songName, int lengthInSeconds, String singer, Movie movie) {
	super();
	this.songName = songName;
	this.lengthInSeconds = lengthInSeconds;
	this.singer = singer;
	this.movie = movie;
}

public int getSongCode() {
	return songCode;
}
public void setSongCode(int songCode) {
	this.songCode = songCode;
}
public String getSongName() {
	return songName;
}
public void setSongName(String songName) {
	this.songName = songName;
}
public int getLengthInSeconds() {
	return lengthInSeconds;
}
public void setLengthInSeconds(int lengthInSeconds) {
	this.lengthInSeconds = lengthInSeconds;
}
public String getSinger() {
	return singer;
}
public void setSinger(String singer) {
	this.singer = singer;
}
@Override
public String toString() {
	return "Song [songCode=" + songCode + ", songName=" + songName + ", lengthInSeconds=" + lengthInSeconds
			+ ", singer=" + singer + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + lengthInSeconds;
	result = prime * result + ((singer == null) ? 0 : singer.hashCode());
	result = prime * result + songCode;
	result = prime * result + ((songName == null) ? 0 : songName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Song other = (Song) obj;
	if (lengthInSeconds != other.lengthInSeconds)
		return false;
	if (singer == null) {
		if (other.singer != null)
			return false;
	} else if (!singer.equals(other.singer))
		return false;
	if (songCode != other.songCode)
		return false;
	if (songName == null) {
		if (other.songName != null)
			return false;
	} else if (!songName.equals(other.songName))
		return false;
	return true;
}

}

package com.cg.movie.services;
import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
public interface MovieServices {
public int createMovie(Movie movie);
public  Movie getMovieDetails(int movieId);
public boolean removeMovie(int movieId);
//public Song createSong(Song song);
public boolean removeSong(int songId);
public Song getSongDetails(int songId);
public List<Movie> getAllMovies();
Song createSong(String songName, int lengthInSeconds, String singer, int movieId);
}

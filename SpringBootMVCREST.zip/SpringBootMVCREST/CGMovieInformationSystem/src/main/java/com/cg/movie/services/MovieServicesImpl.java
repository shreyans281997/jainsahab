package com.cg.movie.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.daoservices.MovieDaoServices;
import com.cg.movie.daoservices.SongDaoServices;
import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.exceptions.SongNotFoundException;

@Component("movieServices")
public class MovieServicesImpl implements MovieServices {
	@Autowired
	private MovieDaoServices moviedaoImpl;
	@Autowired
	private SongDaoServices songdaoImpl;
	@Override
	public int createMovie(Movie movie) {
     movie=moviedaoImpl.save(movie);
		return movie.getMovieCode();
	}

	@Override
	public Movie getMovieDetails(int movieId) {
		return moviedaoImpl.findById(movieId).orElseThrow(()->new MovieNotFoundException("No such movie is available"));
	}

	@Override
	public boolean removeMovie(int movieId) {
		moviedaoImpl.delete(getMovieDetails(movieId));
		return true;
	}

	@Override
	public Song createSong(String songName, int lengthInSeconds, String singer, int movieId ) {
		Movie movie=getMovieDetails(movieId);
		Song song=new Song(songName, lengthInSeconds, singer, movie);
		song=songdaoImpl.save(song);
		return song;
	}

	@Override
	public boolean removeSong(int songId) {
		songdaoImpl.delete(getSongDetails(songId));
		return false;
	}

	@Override
	public Song getSongDetails(int songId) {
		Song song=songdaoImpl.findById(songId).orElseThrow(()->new SongNotFoundException("Invalid song name"));
		return song;
	}
	public List<Movie> getAllMovies(){
		return moviedaoImpl.findAll();
	}
    

}

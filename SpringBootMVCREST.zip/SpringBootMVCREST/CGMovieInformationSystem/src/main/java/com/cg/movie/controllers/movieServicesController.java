package com.cg.movie.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.services.MovieServices;

@Controller
public class movieServicesController {
	@Autowired
	MovieServices movieServices;
	@RequestMapping(value= {"/getMovieDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestParam(@RequestParam int movieId) throws MovieNotFoundException{
		Movie movie=movieServices.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}  
	@RequestMapping(value="/acceptMovieDetails",method=RequestMethod.POST, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptMovieDetails(@ModelAttribute Movie movie){
		int movieId=movieServices.createMovie(movie);
		return new ResponseEntity<>("Movie details successfully added with ID:- "+movieId,HttpStatus.OK);
	}
	@RequestMapping(value="/removeMovieDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeMovieDetails(@RequestParam int movieId){
		movieServices.removeMovie(movieId);
		return new ResponseEntity<>("Movie removed successfully",HttpStatus.OK);
	}
	@RequestMapping(value="/acceptSongDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptSongDetails(@RequestParam int movieId,String songName, int lengthInSeconds, String singer){
		Song song=movieServices.createSong(songName,lengthInSeconds,singer,movieId);
		return new ResponseEntity<>("Song details successfully added:- "+song,HttpStatus.OK);
	}
	@RequestMapping(value="/removeSongDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeSongDetails(@RequestParam int songId){
		movieServices.removeSong(songId);
		return new ResponseEntity<>("Song removed successfully",HttpStatus.OK);
	}

	@RequestMapping(value="/getSongDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<String> getSongDetails(@RequestParam int songId){
		Song song=movieServices.getSongDetails(songId);
		return new ResponseEntity<>("Song Details:"+song,HttpStatus.OK);
	}
	@RequestMapping(value="/getAllMovieDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Movie>> getAllMovieDetails(){
		return new ResponseEntity<List<Movie>>(movieServices.getAllMovies(),HttpStatus.OK);
	}
}

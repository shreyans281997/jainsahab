package com.cg.movie.beans;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
public class Movie {
@Id
@SequenceGenerator(name="movieCode",initialValue=1001,allocationSize=1,sequenceName="movieId")
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="movieCode") 
private int movieCode;
private String movieName;
private String directorName;
private int timeInMinutes;
private String genre;
@OneToMany(mappedBy="movie", cascade=CascadeType.ALL)
@MapKey
@JsonManagedReference
public Map<Integer,Song> song;
public Movie() {}
public Movie(String movieName, String directorName, int timeInMinutes, String genre, Map<Integer, Song> song) {
	super();
	this.movieName = movieName;
	this.directorName = directorName;
	this.timeInMinutes = timeInMinutes;
	this.genre = genre;
	this.song = song;
}
public int getMovieCode() {
	return movieCode;
}
public void setMovieCode(int movieCode) {
	this.movieCode = movieCode;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getDirectorName() {
	return directorName;
}
public void setDirectorName(String directorName) {
	this.directorName = directorName;
}
public int getTimeInMinutes() {
	return timeInMinutes;
}
public void setTimeInMinutes(int timeInMinutes) {
	this.timeInMinutes = timeInMinutes;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public Map<Integer, Song> getSong() {
	return song;
}
public void setSong(Map<Integer, Song> song) {
	this.song = song;
}
@Override
public String toString() {
	return "Movie [movieCode=" + movieCode + ", movieName=" + movieName + ", directorName=" + directorName
			+ ", timeInMinutes=" + timeInMinutes + ", genre=" + genre + ", song=" + song + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((directorName == null) ? 0 : directorName.hashCode());
	result = prime * result + ((genre == null) ? 0 : genre.hashCode());
	result = prime * result + movieCode;
	result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
	result = prime * result + ((song == null) ? 0 : song.hashCode());
	result = prime * result + timeInMinutes;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Movie other = (Movie) obj;
	if (directorName == null) {
		if (other.directorName != null)
			return false;
	} else if (!directorName.equals(other.directorName))
		return false;
	if (genre == null) {
		if (other.genre != null)
			return false;
	} else if (!genre.equals(other.genre))
		return false;
	if (movieCode != other.movieCode)
		return false;
	if (movieName == null) {
		if (other.movieName != null)
			return false;
	} else if (!movieName.equals(other.movieName))
		return false;
	if (song == null) {
		if (other.song != null)
			return false;
	} else if (!song.equals(other.song))
		return false;
	if (timeInMinutes != other.timeInMinutes)
		return false;
	return true;
}

}


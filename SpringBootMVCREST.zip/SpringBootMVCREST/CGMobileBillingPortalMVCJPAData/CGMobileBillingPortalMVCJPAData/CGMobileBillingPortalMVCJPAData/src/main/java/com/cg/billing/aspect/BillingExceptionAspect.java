package com.cg.billing.aspect;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
@ControllerAdvice
public class BillingExceptionAspect {
	@ExceptionHandler(BillDetailsNotFoundException.class)
	public ModelAndView handleInvalidAmountException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("bill", new Bill());
		return modelAndView;
	}
		@ExceptionHandler(CustomerDetailsNotFoundException.class)
		public ModelAndView handleInvalidAccountTypeException(Exception e) {
		ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
		modelAndView.addObject("customer", new Customer());
			return modelAndView;
		}
		@ExceptionHandler(InvalidBillMonthException.class)
		public ModelAndView handleInsufficientAmountException(Exception e) {
			return new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
			//modelAndView.addObject("account", new Account());
			//return modelAndView;
	}
		@ExceptionHandler(PlanDetailsNotFoundException.class)
		public ModelAndView handleInvalidPinNumberException(Exception e) {
			ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
			modelAndView.addObject("plan", new Plan());
			return modelAndView;
		}
		@ExceptionHandler(PostpaidAccountNotFoundException.class)
		public ModelAndView handleAccountNotFoundException(Exception e) {
			ModelAndView modelAndView = new ModelAndView("exceptionPage","errorMessage",e.getMessage()); 
			//ModelAndView modelAndView1 = new ModelAndView("depositPage","errorMessage",e.getMessage()); 
            modelAndView.addObject("postpaidAccount", new PostpaidAccount());
			return modelAndView;
		}
}

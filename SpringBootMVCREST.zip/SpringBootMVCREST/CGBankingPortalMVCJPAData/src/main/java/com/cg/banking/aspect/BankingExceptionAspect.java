package com.cg.banking.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@ControllerAdvice
public class BankingExceptionAspect {
	
		@ExceptionHandler(InvalidAmountException.class)
	public ModelAndView handleInvalidAmountException(Exception e) {
	ModelAndView modelAndView = new ModelAndView("registrationPage","errorMessage",e.getMessage()); 
	modelAndView.addObject("account", new Account());
		return modelAndView;
	}
		@ExceptionHandler(InvalidAccountTypeException.class)
		public ModelAndView handleInvalidAccountTypeException(Exception e) {
		ModelAndView modelAndView = new ModelAndView("registrationPage","errorMessage",e.getMessage()); 
		modelAndView.addObject("account", new Account());
			return modelAndView;
		}
		@ExceptionHandler(InsufficientAmountException.class)
		public ModelAndView handleInsufficientAmountException(Exception e) {
			return new ModelAndView("withdrawPage","errorMessage",e.getMessage()); 
			//modelAndView.addObject("account", new Account());
			//return modelAndView;
	}
		@ExceptionHandler(InvalidPinNumberException.class)
		public ModelAndView handleInvalidPinNumberException(Exception e) {
			ModelAndView modelAndView = new ModelAndView("withdrawPage","errorMessage",e.getMessage()); 
			modelAndView.addObject("account", new Account());
			return modelAndView;
		}
		@ExceptionHandler(AccountNotFoundException.class)
		public ModelAndView handleAccountNotFoundException(Exception e) {
			ModelAndView modelAndView = new ModelAndView("withdrawPage","errorMessage",e.getMessage()); 
			//ModelAndView modelAndView1 = new ModelAndView("depositPage","errorMessage",e.getMessage()); 
            modelAndView.addObject("account", new Account());
			return modelAndView;
		}
}

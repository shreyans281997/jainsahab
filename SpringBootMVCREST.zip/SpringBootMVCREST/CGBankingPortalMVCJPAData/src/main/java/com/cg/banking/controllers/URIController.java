package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.banking.beans.Account;

@Controller
public class URIController {
	private Account account;

	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}

	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/deposit")
	public String getDepositPage() {
		return "depositPage";
	}
	@RequestMapping("/transfer")
	public String getfundsTransferPage() {
		return "fundsTransferPage";
	}
	@RequestMapping("/withdraw")
	public String getWithdrawPage() {
		return "withdrawPage";
	}
	@RequestMapping("/accountDetails")
	public String getAccountDetailsPage() {
		return "accountDetailsPage";
	}
	@RequestMapping("/transactionDetails")
	public String getTransactionDetailsPage() {
		return "transactionDetailsPage";
	}
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}

}

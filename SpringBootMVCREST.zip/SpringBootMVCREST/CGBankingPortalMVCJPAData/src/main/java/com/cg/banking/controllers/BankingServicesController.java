package com.cg.banking.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
@Controller
public class BankingServicesController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/registrationAccount")
	public ModelAndView registerAssociate(@ModelAttribute Account account) throws InvalidAmountException, InvalidAccountTypeException {
		return new ModelAndView("registrationSuccessPage","account",bankingServices.openAccount(account));
	}
	@RequestMapping("/depositMoney")
	public ModelAndView depositMoney(@RequestParam long accountNumber,int amount) throws AccountNotFoundException, AccountBlockedException {
		return new ModelAndView("depositPage","balance",bankingServices.depositAmount(accountNumber,amount));
	}
	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam int accountNoTo, float accountBalance,int pinNumber, int accountNoFrom)throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		boolean fundTransferStatus=bankingServices.fundTransfer(accountNoTo,accountNoFrom,accountBalance,pinNumber);
		return new ModelAndView("fundsTransferPage","fundTransferStatus", fundTransferStatus);
	}
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmount(@RequestParam int accountNo, float accountBalance,int pinNumber )throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		float totalAmount=bankingServices.withdrawAmount(accountNo,accountBalance,pinNumber);
		return new ModelAndView("withdrawPage","balance", totalAmount);
	}
	@RequestMapping("/accountInfo")
	public ModelAndView accountDetails(@RequestParam int accountNumber)throws AccountNotFoundException {
		Account account=bankingServices.getAccountDetails(accountNumber);
		return new ModelAndView("accountDetailsPage","account", account);
	}
	@RequestMapping("/accountTransactionDetails")
	public ModelAndView transactionDetails(@RequestParam int accountNumber) throws AccountNotFoundException{
		List<Transaction> transactions=bankingServices.getAccountAllTransaction(accountNumber);
		return new ModelAndView("transactionDetailsPage","transactions",transactions);
		
	}
	
}

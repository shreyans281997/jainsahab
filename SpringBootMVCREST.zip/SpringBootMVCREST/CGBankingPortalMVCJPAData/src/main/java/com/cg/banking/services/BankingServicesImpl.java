package com.cg.banking.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;

import com.cg.banking.daoservices.TransactionDAO;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO daoImpl;
	@Autowired
	private TransactionDAO tDaoImpl;
	Transaction transaction;
	Transaction transaction1;
	Account account;
	Account account1;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if (account.getAccountBalance()<500)
			throw new InvalidAmountException("Deposit amount greater than 500");
		if ((account.getAccountType().equalsIgnoreCase("Savings")) || (account.getAccountType().equalsIgnoreCase("current")))
		{

			account.setPinNumber((int)(Math.random()*10000));
			account.setAccountStatus("active");
			account=daoImpl.save(account);
		}
		else
			throw new InvalidAccountTypeException("Invalid type");
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=daoImpl.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account not found"));
		if(account.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		else{
			account.setAccountBalance(account.getAccountBalance()+amount);
			daoImpl.save(account);
			transaction=new Transaction(amount,"Deposit",account);
			transaction=tDaoImpl.save(transaction);
		}
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) 
			throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getPinNumber()==pinNumber){
			if(amount>account.getAccountBalance())
				throw new InsufficientAmountException("Insuffient amount in your account");
			else{
				account.setAccountBalance(account.getAccountBalance()-amount);
				transaction=new Transaction(amount,"Withdraw",account);
				tDaoImpl.save(transaction);
				daoImpl.save(account);
			}
		}
		else {
			throw new InvalidPinNumberException();
		}
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		depositAmount(accountNoTo, transferAmount); 
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		account= daoImpl.findById(accountNo).orElseThrow(()->new AccountNotFoundException("No Account found"));
		return account;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException {
		Account account= getAccountDetails(accountNo);
		List<Transaction> transactions=new ArrayList<>(account.getTransactions().values());
		return transactions;
	}
	@Override
	public String accountStatus(long accountNo) 
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= getAccountDetails(accountNo);
		return account.getAccountStatus();
	}
	@Override
	public void checkPin(int counter, long accountNo) throws AccountBlockedException {
		if(counter==0) {
			account.setAccountStatus("Blocked");
			daoImpl.save(account);
			throw new AccountBlockedException();
		}
	}
}
